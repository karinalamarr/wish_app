from django.apps import AppConfig


class TvshowsAppConfig(AppConfig):
    name = 'tvShows_app'
